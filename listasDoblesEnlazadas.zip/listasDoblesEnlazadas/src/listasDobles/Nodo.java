package listasDobles;



public class Nodo {

	private String elemento;
	private Nodo ant;
	private Nodo sig;
	
	
	public Nodo(String elemento, Nodo ant, Nodo sig) {
		super();
		this.elemento = elemento;
		this.ant = ant;
		this.sig = sig;
	}

	public String getElemento(){
		return elemento;
	}
	
	public void setElemento(String nuevoE){
		elemento=nuevoE;
	}

	public Nodo getAnt() {
		return ant;
	}

	public void setAnt(Nodo ant) {
		this.ant = ant;
	}

	public Nodo getSig() {
		return sig;
	}

	public void setSig(Nodo sig) {
		this.sig = sig;
	}
	
	
	
}
