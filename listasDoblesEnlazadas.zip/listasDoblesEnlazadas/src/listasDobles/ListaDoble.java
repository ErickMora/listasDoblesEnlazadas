package listasDobles;

public class ListaDoble {
	private Nodo inicio;
	private Nodo fin;
	private int nElementos=0;

	public ListaDoble(){
		inicio =new Nodo(null,null,null);
		fin= new Nodo(null,inicio,null);
		inicio.setSig(fin);
		nElementos=0;
	}

	public int getnElementos() {
		return nElementos;
	}

	public boolean listaVacia(){
		return nElementos==0;
	}	

	public void insertarEntre(String elemento, Nodo ant, Nodo sig){
		Nodo aux=new Nodo(elemento,ant,sig);
		ant.setSig(aux);
		sig.setAnt(aux);
		nElementos++;		
	}

	public void insertarPrimero(String elemento){
		insertarEntre(elemento,inicio,inicio.getSig());
	}

	public void insertarUltimo(String elemento){
		insertarEntre(elemento,fin.getAnt(),fin);
	}

	public Nodo buscarElemento(String elemento)
	{
		Nodo i;
		for(i=inicio; i!=null; i=i.getSig())
			if(elemento == i.getElemento())
			{		
				System.out.println("Elemento encontrado");
				return i;
			}
		System.out.println("Elemento no encontrado");
		return null;
	}

	public Nodo buscarElemento(int pos)
	{
		Nodo i;
		int aux=0;
		for(i=inicio; i!=null; i=i.getSig()){

			if(pos == aux)
			{		
				System.out.println("Indice encontrado");
				return i;
			}
			aux++;
		}
		System.out.println("Indice no encontrado");
		return null;
	}

	public Nodo eliminarElemento(String elemento){
		if(buscarElemento(elemento)==null){
			System.out.println("No se puede eliminar");
			return null;
		}
		else
		{
		Nodo ant=buscarElemento(elemento).getAnt();
		Nodo sig=buscarElemento(elemento).getSig();
		ant.setSig(sig);
		sig.setAnt(ant);
		nElementos--;
		
		return ant.getSig();
		}

	}

	public Nodo eliminarElemento(int pos){
		if(buscarElemento(pos)==null){
			System.out.println("No se puede eliminar");
			return null;
		}
		else
		{
		Nodo ant=buscarElemento(pos).getAnt();
		Nodo sig=buscarElemento(pos).getSig();
		ant.setSig(sig);
		sig.setAnt(ant);
		nElementos--;
		return ant.getSig();
		}

	}

	public String imprimirLista() {
		Nodo n=inicio;
		String elementosLista="";
		if(listaVacia())
			return null;
		else{	
			while (n!=null){
				elementosLista+=n.getElemento()+"  ";
				n=n.getSig();
			}
			return elementosLista;
		}
	}


}
