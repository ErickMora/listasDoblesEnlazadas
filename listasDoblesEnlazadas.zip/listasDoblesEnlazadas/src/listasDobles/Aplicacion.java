package listasDobles;

import java.io.IOException;

public class Aplicacion {
	
	public static void main(String args[]) throws IOException
	{
		ListaDoble lista=new ListaDoble();
		
		lista.buscarElemento(null);
		System.out.println(lista.getnElementos());
		System.out.println(lista.imprimirLista());
		lista.insertarPrimero("AA");
		System.out.println(lista.imprimirLista());
		lista.insertarUltimo("BB");
		System.out.println(lista.imprimirLista());
		lista.buscarElemento("BB");
		lista.buscarElemento("9");
		System.out.println(lista.getnElementos());
		lista.buscarElemento(3);
		lista.eliminarElemento("AA");
		System.out.println(lista.imprimirLista());
		lista.eliminarElemento(10);
		System.out.println(lista.imprimirLista());
	}

}
