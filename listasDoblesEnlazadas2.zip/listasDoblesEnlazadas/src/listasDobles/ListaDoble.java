package listasDobles;

public class ListaDoble {
	private Nodo inicio;
	private Nodo fin;
	private int nElementos=0;

	public ListaDoble(Nodo inicio, Nodo fin, int nElementos) {
		super();
		inicio =new Nodo(null,null,null);
		fin= new Nodo(null,null,null);
		nElementos=0;
		inicio.setSig(fin);
		fin.setAnt(inicio);
		this.inicio = inicio;
		this.fin = fin;
		this.nElementos = nElementos;
	}

	public int getnElementos() {
		return nElementos;
	}

	public boolean listaVacia(){
		return nElementos==0;
	}	

	public void insertarEntre(String elemento, Nodo ant, Nodo sig){
		Nodo aux=new Nodo(elemento,ant,sig);
		ant.setSig(aux);
		sig.setAnt(aux);
		nElementos++;		
	}

	public void insertarPrimero(String elemento){
		insertarEntre(elemento,inicio,inicio.getSig());
	}

	public void insertarUltimo(String elemento){
		insertarEntre(elemento,fin.getAnt(),fin);
	}

	public Nodo buscarElemento(String elemento)
	{
		Nodo i;
		for(i=inicio; i!=null; i=i.getSig())
			if(elemento == i.getElemento())
			{		
				System.out.println("Elemento encontrado");
				return i;
			}
		System.out.println("Elemento no encontrado");
		return null;
	}

	public Nodo buscarElemento(int pos)
	{
		Nodo i;
		int aux=0;
		for(i=inicio; i!=null; i=i.getSig()){

			if(pos == aux)
			{		
				System.out.println("Indice encontrado");
				return i;
			}
			aux++;
		}
		System.out.println("Indice no encontrado");
		return null;
	}

	public Nodo eliminarElemento(String elemento){
		if(buscarElementoEliminar(elemento)==null){
			System.out.println("No se puede eliminar");
			return null;
		}
		else
		{
		Nodo ant=buscarElementoEliminar(elemento).getAnt();
		Nodo sig=buscarElementoEliminar(elemento).getSig();
		ant.setSig(sig);
		sig.setAnt(ant);
		nElementos--;
		System.out.println("Elemento eliminado");
		return ant.getSig();
		}

	}

	public Nodo eliminarElemento(int pos){
		if(buscarElementoEliminar(pos)==null){
			System.out.println("No se puede eliminar");
			return null;
		}
		else
		{
		Nodo ant=buscarElementoEliminar(pos).getAnt();
		Nodo sig=buscarElementoEliminar(pos).getSig();
		ant.setSig(sig);
		sig.setAnt(ant);
		nElementos--;
		System.out.println("Elemento eliminado");
		return ant.getSig();
		}

	}

	public String imprimirLista() {
		Nodo n=inicio;
		String elementosLista="";
		if(listaVacia())
			return null;
		else{	
			while (n!=null){
				elementosLista+=n.getElemento()+"  ";
				n=n.getSig();
			}
			return elementosLista;
		}
	}
	
	public String imprimirAtras() {
		Nodo n=fin;
		String elementosLista="";
		if(listaVacia())
			return null;
		else{	
			while (n!=null){
				elementosLista+=n.getElemento()+"  ";
				n=n.getAnt();
			}
			return elementosLista;
		}
	}
	
	
	
	public Nodo buscarElementoEliminar(String elemento)
	{
		Nodo i;
		for(i=inicio; i!=null; i=i.getSig())
			if(elemento == i.getElemento())
			{		
				return i;
			}
		System.out.println("Elemento no encontrado");
		return null;
	}

	public Nodo buscarElementoEliminar(int pos)
	{
		Nodo i;
		int aux=0;
		for(i=inicio; i!=null; i=i.getSig()){

			if(pos == aux)
			{		
				return i;
			}
			aux++;
		}
		System.out.println("Indice no encontrado");
		return null;
	}



}
