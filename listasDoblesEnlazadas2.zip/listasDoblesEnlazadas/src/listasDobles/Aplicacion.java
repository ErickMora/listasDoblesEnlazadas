package listasDobles;

import java.io.IOException;

public class Aplicacion {
	
	public static void main(String args[]) throws IOException
	{
		ListaDoble lista=new ListaDoble(null,null,0);
		
		lista.insertarPrimero("AA");
		System.out.println(lista.imprimirLista());
		lista.insertarPrimero("27");
		System.out.println(lista.imprimirLista());
		lista.insertarUltimo("BB");
		System.out.println(lista.imprimirLista());
		lista.insertarUltimo("99");
		System.out.println(lista.imprimirLista());
		System.out.println(lista.imprimirAtras());
		lista.buscarElemento("BB");
		lista.buscarElemento("9");
		lista.buscarElemento(2);
		lista.buscarElemento(8);
		lista.eliminarElemento("AA");
		System.out.println(lista.imprimirLista());
		lista.eliminarElemento(10);
		System.out.println(lista.imprimirLista());
		lista.eliminarElemento("hghtjg");
		System.out.println(lista.imprimirLista());
		lista.eliminarElemento(3);
		System.out.println(lista.imprimirLista());
	}
	
}
